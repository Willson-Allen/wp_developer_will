<p>Greetings from footer.php</p>

<?php wp_footer(); ?>
</body>
</html>